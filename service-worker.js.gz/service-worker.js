// In development, always fetch from network
self.addEventListener('fetch', () => { });
