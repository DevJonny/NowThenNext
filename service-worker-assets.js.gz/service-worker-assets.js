self.assetsManifest = {
  "version": "BpjmbER+",
  "assets": [
    {
      "hash": "sha256-1f3PQxUA8XQEW0e6auZAiTHMDa8t135SRHMvBgGsD4M=",
      "url": "NowThenNext.Web.styles.css"
    },
    {
      "hash": "sha256-Z/I1339InDuOPqcxuznblrUyBaYIXu9HFBq2z/gXq8A=",
      "url": "_content/Blazored.Modal/Blazored.Modal.bundle.scp.css"
    },
    {
      "hash": "sha256-kA2z2nG9FrUdWS/uJrfB+pfqUujsR3MLSrJeQKsao/Q=",
      "url": "_content/Blazored.Modal/BlazoredModal.razor.js"
    },
    {
      "hash": "sha256-OaMAAd5n7ORfyur5e3QIyEVKJ76MKIvwbg7/icnnYcU=",
      "url": "_framework/Blazored.LocalStorage.12n6dz54qr.wasm"
    },
    {
      "hash": "sha256-Y6pVrSnmzq2FCEnAkNngv+mtNlIljEmH3BEmGpr5jEQ=",
      "url": "_framework/Blazored.Modal.h7t7ava08f.wasm"
    },
    {
      "hash": "sha256-YHs2Vx43ZYUJExY7JRrB4FUZ1ev6DAYRa580vKrWHWA=",
      "url": "_framework/Microsoft.AspNetCore.Components.4rha7r1xbj.wasm"
    },
    {
      "hash": "sha256-Pn6JYBKIe1xLU4zb0BoALVzfroizWvhgFsG8GSD0GBA=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.ynirj19r8x.wasm"
    },
    {
      "hash": "sha256-0oR49yHee8gDvfVtSjvtIs7RVzZtv6sn4BPEkzhsOOk=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.ikvkgqjzye.wasm"
    },
    {
      "hash": "sha256-AyL87FvJMf14Dcn8HeQ3n2veg/RQGVGCjfpJPt1RQC4=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.f9jq6u05xu.wasm"
    },
    {
      "hash": "sha256-TUkUL2Leb3zmGe8ZZUHAzyb8vZoEzua1H8f8stc7xRw=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.77nptesqpn.wasm"
    },
    {
      "hash": "sha256-0iZA+rfvr3lLmK5V18g0LZCU41c3mbTL9jNYRoavdB0=",
      "url": "_framework/Microsoft.Extensions.Configuration.ell6o7ap7i.wasm"
    },
    {
      "hash": "sha256-gj2zwP9Eq06czznnKp/VWoCXvPKBxSVKpNnqX1T00fA=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.yn6jufqcki.wasm"
    },
    {
      "hash": "sha256-EPey4pvx6aL8aj8zL05ip1ZJSUG7DjjOrtL9aPRDYPw=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.g8opmrm9gr.wasm"
    },
    {
      "hash": "sha256-a881iT/kmq3LnryJklnQzsMD93/W6dM0x/3xSE38e6I=",
      "url": "_framework/Microsoft.Extensions.Logging.5g1hnmwyc5.wasm"
    },
    {
      "hash": "sha256-orBsRyrmQ2tga4R/Z9nE0NDH6jGWYutysMdSEM1i6/o=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.udb0ns9y9g.wasm"
    },
    {
      "hash": "sha256-zRPgvUtRauLs9LddjREkF3heeNb3yaqirhsXBi0kGQ8=",
      "url": "_framework/Microsoft.Extensions.Options.nbtz5iwb4h.wasm"
    },
    {
      "hash": "sha256-TYdWPCwhKBdHQ79Fa7lunjzdUXfcxyaR1fAk0y11/ig=",
      "url": "_framework/Microsoft.Extensions.Primitives.tcgeh3akx1.wasm"
    },
    {
      "hash": "sha256-99wG3VH14sWkwPaF5rX6YAcJvtAhDuqonwihvj2m5HA=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.heoad7mujs.wasm"
    },
    {
      "hash": "sha256-rarQUJUlQ7tQIIdRQKwbHfyOByYiBxCDUn1XeVlyx+M=",
      "url": "_framework/Microsoft.JSInterop.tce4t7t8du.wasm"
    },
    {
      "hash": "sha256-eRXKVCS2eMy8h9N8BjkXXPPuyY93TjRHfHGhlfXOWEo=",
      "url": "_framework/NowThenNext.Web.j1tminevrn.wasm"
    },
    {
      "hash": "sha256-nT1CaQDjTJXz/mfORKwKIIoP1hyJEnEKYfMPa6mtLj4=",
      "url": "_framework/System.Collections.38wh5gejlk.wasm"
    },
    {
      "hash": "sha256-cqzcHSwS9ehagxX+t9ixAOyXAEOHC3JHlwzyakXTtbU=",
      "url": "_framework/System.Collections.Concurrent.upxfk4jomb.wasm"
    },
    {
      "hash": "sha256-HW+nFZlpdU0r7grI5GjVlMgoEpBVt692eM875MFMbvo=",
      "url": "_framework/System.Collections.Immutable.13797fe0rc.wasm"
    },
    {
      "hash": "sha256-4qXZbapsDZssS5DvMcw49dIUrVfBIKsZ0zbsHsukBPQ=",
      "url": "_framework/System.ComponentModel.m3ms7gmx60.wasm"
    },
    {
      "hash": "sha256-Xc0cY8EWWDAQ9zI6jjt4tUjAnWPdFXgH8DkZc0IcFFE=",
      "url": "_framework/System.Console.x3dohxy6z0.wasm"
    },
    {
      "hash": "sha256-Kbanr+6xq8R0+Fuh6Tyw7JoPNulBwn71ItrfDC/AwLM=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.5t53yhj4qa.wasm"
    },
    {
      "hash": "sha256-uEVVMYx7abWgasKfPzSB6wOMoCpVEVv4EcEAOCa4ph0=",
      "url": "_framework/System.IO.Pipelines.0uhw8kopg1.wasm"
    },
    {
      "hash": "sha256-ook+mbAs03xnCselRJRawvXPEBeSI2j6epEdAlY3D7M=",
      "url": "_framework/System.Linq.2srgxu6979.wasm"
    },
    {
      "hash": "sha256-ON7LdppuSiK+Los/mM4y9ImsccszpWRjTZxs3WPaors=",
      "url": "_framework/System.Memory.s3k4fpjtbw.wasm"
    },
    {
      "hash": "sha256-uaDJXUjtVrPMO5gJ5/dikCyyZpnq9v69Cd/kmBYzqkE=",
      "url": "_framework/System.Net.Http.Json.firoqhkdnq.wasm"
    },
    {
      "hash": "sha256-1jGquepdnjTt/kvLu3rrly0Fbe8uOo6UqEp+OsVvwBA=",
      "url": "_framework/System.Net.Http.mlq2bkqq7d.wasm"
    },
    {
      "hash": "sha256-nezaQh05iG5l4rQswqNPl/zET8UwMn5b44CpxdCrhyQ=",
      "url": "_framework/System.Net.Primitives.9x72ktbyas.wasm"
    },
    {
      "hash": "sha256-3vKaIS7idF5eUgPnCUXDUKrRZEldgA6J8os7TUaM/KM=",
      "url": "_framework/System.Private.CoreLib.6eq9di1ld8.wasm"
    },
    {
      "hash": "sha256-Fky57b+zaPUMy7pWv/fTH7f1UXQ5WaliV8aEmWvIovE=",
      "url": "_framework/System.Private.Uri.umma3qruyb.wasm"
    },
    {
      "hash": "sha256-uo4WQ39eiOB+w/weMzCVCfXQey09VlzpTm+e6aR83IA=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.era55l3sbb.wasm"
    },
    {
      "hash": "sha256-hreS0NoGMM19EKQ6ylbxGsRxYoxYvwa9JKswGDN5kM8=",
      "url": "_framework/System.Runtime.abrdwvf0tn.wasm"
    },
    {
      "hash": "sha256-pdKoJJI3yt1NF2Lx1MGO++1RtPSzree8qeWFFtJOnKo=",
      "url": "_framework/System.Text.Encodings.Web.5w28q6ifw5.wasm"
    },
    {
      "hash": "sha256-y+PDYx7l1EwO+ugB+bK9+ZOSqjWlNNNvHpofi1do3Uo=",
      "url": "_framework/System.Text.Json.71q4bzfl1p.wasm"
    },
    {
      "hash": "sha256-A29j8BigKS89/5EBW6GETUPxSN+JNi8uuKehrofYFmE=",
      "url": "_framework/System.Text.RegularExpressions.3kr2n0wcz9.wasm"
    },
    {
      "hash": "sha256-F5PSI/gBuwoWEF7SbdO7+2/Lo9hw0ISBKug8avOpxP0=",
      "url": "_framework/System.Threading.vuopdrx302.wasm"
    },
    {
      "hash": "sha256-w4spZabIK0sFCrwHM5gnOUKSjaJcuNKwVa385dv/vpo=",
      "url": "_framework/blazor.boot.json"
    },
    {
      "hash": "sha256-lh8bY3DINgTiqGL/cwOeVaJGdfE2ex1o8MzwCbmlZZE=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-5TAd2is0AgjjYIAuEN8Bd5ZPoTk8dKE9RRtIQr4H5Lw=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-89jyB8DlCnV2BPMV477jOe1Sm0WXwVf8RuoSPsj4Ym8=",
      "url": "_framework/dotnet.native.3c4wvb350q.wasm"
    },
    {
      "hash": "sha256-LX9rFEWGVxhkOkAVPG0w5RxPwzPBlEUz6dQNjWS7M+M=",
      "url": "_framework/dotnet.native.hvg7u8bimp.js"
    },
    {
      "hash": "sha256-dCmS9Zx4egtLYSUgTI3R6gMS+Yg8MkzxW1CgEMJKAEw=",
      "url": "_framework/dotnet.runtime.cymp1amu5g.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-NdR6BBtG0A492/UR/PUoJ0g3Y19lJ4fdogIrJWMC6TE=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-4mWsDy3aHl36ZbGt8zByK7Pvd4kRUoNgTYzRnwmPHwg=",
      "url": "favicon.png"
    },
    {
      "hash": "sha256-DbpQaq68ZSb5IoPosBErM1QWBfsbTxpJqhU0REi6wP4=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-oEo6d+KqX5fjxTiZk/w9NB3Mi0+ycS5yLwCKwr4IkbA=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-mtP/VqG2uhTXUQnFSmwagwPOwxzqOoAQFUyi/ulmGd4=",
      "url": "index.html"
    },
    {
      "hash": "sha256-71LE0dkB0ndkAAjlzeSTzsyvSN61zDJsALUVpxas+Js=",
      "url": "js/app.js"
    },
    {
      "hash": "sha256-Yy5/hBqRmmU2MJ1TKwP2aXoTO6+OjzrLmJIsC2Wy4H8=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.css"
    },
    {
      "hash": "sha256-xAT+n25FE5hvOjj2fG4YdOwr1bl4IlAJBNg6PbhLT2E=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.css.map"
    },
    {
      "hash": "sha256-5nDHMGiyfZHl3UXePuhLDQR9ncPfBR1HJeZLXyJNV24=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.min.css"
    },
    {
      "hash": "sha256-kgL+xwVmM8IOs15lnoHt9daR2LRMiBG/cYgUPcKQOY4=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.min.css.map"
    },
    {
      "hash": "sha256-CZxoF8zjaLlyVkcvVCDlc8CeQR1w1RMrvgYx30cs8kM=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.css"
    },
    {
      "hash": "sha256-/siQUA8yX830j+cL4amKHY3yBtn3n8z3Eg+VZ15f90k=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.css.map"
    },
    {
      "hash": "sha256-vMxTcvkC4Ly7LiAT3G8yEy9EpTr7Fge4SczWp07/p3k=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.min.css"
    },
    {
      "hash": "sha256-7GdOlw7U/wgyaeUtFmxPz5/MphdvVSPtVOOlTn9c33Q=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.min.css.map"
    },
    {
      "hash": "sha256-lo9YI82OF03vojdu+XOR3+DRrLIpMhpzZNmHbM5CDMA=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.css"
    },
    {
      "hash": "sha256-RXJ/QZiBfHXoPtXR2EgC+bFo2pe3GtbZO722RtiLGzQ=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.css.map"
    },
    {
      "hash": "sha256-l8vt5oozv958eMd9TFsPAWgl9JJK9YKfbVSs8mchQ84=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.min.css"
    },
    {
      "hash": "sha256-0eqVT62kqRLJh9oTqLeIH4UnQskqVjib8hl2fXxl4lg=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.min.css.map"
    },
    {
      "hash": "sha256-V8psnHoJS/MPlCXWwc/J3tGtp9c3gGFRmqsIQgpn+Gg=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.css"
    },
    {
      "hash": "sha256-OoQVwh7Arp7bVoK2ZiTx2S//KrnPrSPzPZ93CqCMhe8=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.css.map"
    },
    {
      "hash": "sha256-/8jh8hcEMFKyS6goWqnNu7t3EzZPCGdQZgO6sCkI8tI=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.min.css"
    },
    {
      "hash": "sha256-910zw+rMdcg0Ls48ATp65vEn8rd5HvPxOKm2x3/CBII=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.min.css.map"
    },
    {
      "hash": "sha256-2BubgNUPlQSF/0wLFcRXQ/Yjzk9vsUbDAeK2QM+h+yo=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.css"
    },
    {
      "hash": "sha256-Nfjrc4Ur9Fv2oBEswQWIyBnNDP99q+LhL+z9553O0cY=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.css.map"
    },
    {
      "hash": "sha256-KyE9xbKO9CuYx0HXpIKgsWIvXkAfITtiQ172j26wmRs=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.min.css"
    },
    {
      "hash": "sha256-rHDmip4JZzuaGOcSQ1QSQrIbG0Eb3Zja9whqSF1zYIU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.min.css.map"
    },
    {
      "hash": "sha256-H6wkBbSwjua2veJoThJo4uy161jp+DOiZTloUlcZ6qQ=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.css"
    },
    {
      "hash": "sha256-p0BVq5Ve/dohBIdfbrZsoQNu02JSsKh1g0wbyiQiUaU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.css.map"
    },
    {
      "hash": "sha256-GAUum6FjwQ8HrXGaoFRnHTqQQLpljXGavT7mBX8E9qU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.min.css"
    },
    {
      "hash": "sha256-o8XK32mcY/FfcOQ1D2HJvVuZ0YTXSURZDLXCK0fnQeA=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.min.css.map"
    },
    {
      "hash": "sha256-GKEF18s44B5e0MolXAkpkqLiEbOVlKf6VyYr/G/E6pw=",
      "url": "lib/bootstrap/dist/css/bootstrap.css"
    },
    {
      "hash": "sha256-KzNVR3p7UZGba94dnCtlc6jXjK5urSPiZ/eNnKTmDkw=",
      "url": "lib/bootstrap/dist/css/bootstrap.css.map"
    },
    {
      "hash": "sha256-PI8n5gCcz9cQqQXm3PEtDuPG8qx9oFsFctPg0S5zb8g=",
      "url": "lib/bootstrap/dist/css/bootstrap.min.css"
    },
    {
      "hash": "sha256-8SM4U2NQpCLGTQLW5D/x3qSTwxVq2CP+GXYc3V1WwFs=",
      "url": "lib/bootstrap/dist/css/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-j5E4XIj1p1kNnDi0x1teX9RXoh1/FNlPvCML9YmRh2Q=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.css"
    },
    {
      "hash": "sha256-3bYWUiiVYMZfv2wq5JnXIsHlQKgSKs/VcRivgjgZ1ho=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.css.map"
    },
    {
      "hash": "sha256-h5lE7Nm8SkeIpBHHYxN99spP3VuGFKl5NZgsocil7zk=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.min.css"
    },
    {
      "hash": "sha256-rTzXlnepcb/vgFAiB+U7ODQAfOlJLfM3gY6IU7eIANk=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.min.css.map"
    },
    {
      "hash": "sha256-eaRXGYhmGipWZPKZGsFT6C4GqhkwHjV4rPu+YPmN1DE=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.js"
    },
    {
      "hash": "sha256-dyv+P3zwWWEZWQLgjtvSUQLN+O3Wd/vQstW1th31QM8=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.js.map"
    },
    {
      "hash": "sha256-CDOy6cOibCWEdsRiZuaHf8dSGGJRYuBGC+mjoJimHGw=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.min.js"
    },
    {
      "hash": "sha256-gq5OUf85nJMRfgU4BRTVbT+StBEWjGmdH/6XyZ+5IKI=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.min.js.map"
    },
    {
      "hash": "sha256-0DOrjIE4cbnrtTD4uvvBa1bunvXb2rDJ+VRgWb3OuQU=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.js"
    },
    {
      "hash": "sha256-VeuPhAWIwd1lsc4FIBhToLmdOdqOrd3kvuN0TEMxRqw=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.js.map"
    },
    {
      "hash": "sha256-QZdFT1ZNdly4rmgUBtXmXFS9BU1FTa+sPe6h794sFRQ=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.min.js"
    },
    {
      "hash": "sha256-3U1409f91QOeKRRqNFmVy1xFutXXzIj3ruCznoJmPbo=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.min.js.map"
    },
    {
      "hash": "sha256-wfw5+oAj06Z3AWjLwUhbcGo0QoGNC7TJUYywDzN3XMk=",
      "url": "lib/bootstrap/dist/js/bootstrap.js"
    },
    {
      "hash": "sha256-gQwFc1CngotWDcVR+4nuk139fzOdQV3RmITRubsKWJE=",
      "url": "lib/bootstrap/dist/js/bootstrap.js.map"
    },
    {
      "hash": "sha256-3gQJhtmj7YnV1fmtbVcnAV6eI4ws0Tr48bVZCThtCGQ=",
      "url": "lib/bootstrap/dist/js/bootstrap.min.js"
    },
    {
      "hash": "sha256-eHrPVqjDvZ+Vj1qg2yK3mSQENNznExNZ5SIOV+W4xCM=",
      "url": "lib/bootstrap/dist/js/bootstrap.min.js.map"
    },
    {
      "hash": "sha256-+YWoKpgvWAOy1jJnIaQYVMEK+Ov/1qozbgBVsMe78IY=",
      "url": "manifest.webmanifest"
    },
    {
      "hash": "sha256-paIeuWnSzjeLGITWkk4p3rcejUsZWCJGPeOK9UhWXtg=",
      "url": "sample-data/weather.json"
    }
  ]
};
